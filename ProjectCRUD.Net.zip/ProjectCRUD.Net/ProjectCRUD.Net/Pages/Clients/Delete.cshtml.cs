using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjectCRUD.Net.Pages.Clients
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
